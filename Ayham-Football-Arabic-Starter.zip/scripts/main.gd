extends Node3D

const TEAM_NAMES := ["العراق 🇮🇶", "برشلونة 🔵🔴", "الأرجنتين 🇦🇷"]
const TEAM_COLORS := [
    [Color("#D71920"), Color("#FFFFFF")],
    [Color("#16408B"), Color("#A50044")],
    [Color("#75AADB"), Color("#FFFFFF")]
]
const GOAL_WIDTH := 7.32
const GOAL_HEIGHT := 2.44

var selected_team := 0
var ball: RigidBody3D
var keeper: Node3D
var keeper_home_x := 0.0
var shot_taken := false
var goals := 0
var attempts := 0
var status_label: Label
var score_label: Label
var team_label: Label
var hint_label: Label
var aim_x := 0.0
var aim_y := 0.0
var shot_cooldown := 0.0
var rng := RandomNumberGenerator.new()
var idle_ball_timer := 0.0
var arabic_font: FontFile

func _ready() -> void:
    rng.randomize()
    arabic_font = load("res://fonts/NotoKufiArabic-Regular.ttf") as FontFile
    _build_world()
    _build_hud()
    _reset_ball()
    _update_team()

func _process(delta: float) -> void:
    _read_aim(delta)
    if shot_cooldown > 0.0:
        shot_cooldown -= delta
    if shot_taken and ball and ball.global_position.y < -1.0:
        _reset_ball()
    if shot_taken and ball and ball.linear_velocity.length() < 0.35 and ball.global_position.z < -1.0:
        idle_ball_timer += delta
        if idle_ball_timer >= 1.2:
            _reset_ball()
    else:
        idle_ball_timer = 0.0
    if keeper:
        var target_x := clamp(aim_x * 2.2, -2.5, 2.5)
        keeper.position.x = move_toward(keeper.position.x, target_x, delta * (1.2 if not shot_taken else 4.0))

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("cycle_team"):
        selected_team = (selected_team + 1) % TEAM_NAMES.size()
        _update_team()
    if event.is_action_pressed("restart"):
        _reset_ball()
    if event.is_action_pressed("shoot") and not shot_taken and shot_cooldown <= 0.0:
        _shoot()
    if event is InputEventJoypadButton and event.pressed:
        # Y / Triangle can also cycle the featured team.
        if event.button_index == 3:
            selected_team = (selected_team + 1) % TEAM_NAMES.size()
            _update_team()

func _read_aim(delta: float) -> void:
    var x := Input.get_axis("move_left", "move_right")
    var y := Input.get_axis("move_down", "move_up")
    aim_x = clamp(aim_x + x * delta * 1.6, -1.0, 1.0)
    aim_y = clamp(aim_y + y * delta * 1.3, -0.45, 0.75)
    if hint_label:
        hint_label.text = "وجّه التسديدة بالأسهم أو العصا اليسرى  |  زر A / ✕ للتسديد  |  B / ○ لإعادة الكرة"

func _build_world() -> void:
    var world := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.45, 0.52, 0.68)
    env.ambient_light_energy = 0.65
    world.environment = env
    add_child(world)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -25, 0)
    sun.light_energy = 1.35
    sun.shadow_enabled = true
    add_child(sun)

    _add_box("أرضية الملعب", Vector3(0, -0.12, -5), Vector3(42, 0.2, 62), Color("#176B3A"))
    for i in range(8):
        var stripe_color := Color("#1B7540") if i % 2 == 0 else Color("#176B3A")
        _add_box("شريط العشب", Vector3(0, -0.005, -29 + i * 7), Vector3(42, 0.015, 7), stripe_color)

    # Goal line, penalty spot and box markings
    _add_box("خط المرمى", Vector3(0, 0.012, -24.0), Vector3(14, 0.025, 0.12), Color.WHITE)
    _add_box("منطقة الجزاء الخلفية", Vector3(0, 0.014, -17.2), Vector3(18.3, 0.025, 0.10), Color.WHITE)
    _add_box("منطقة الجزاء اليسرى", Vector3(-9.1, 0.014, -20.6), Vector3(0.10, 0.025, 6.8), Color.WHITE)
    _add_box("منطقة الجزاء اليمنى", Vector3(9.1, 0.014, -20.6), Vector3(0.10, 0.025, 6.8), Color.WHITE)
    _add_box("علامة الجزاء", Vector3(0, 0.025, -13.0), Vector3(0.28, 0.03, 0.28), Color.WHITE)

    _build_goal()
    _build_stands()
    _build_keeper()
    _build_ball()
    _build_camera()

func _add_box(node_name: String, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
    var mesh_instance := MeshInstance3D.new()
    mesh_instance.name = node_name
    var box := BoxMesh.new()
    box.size = size
    mesh_instance.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.9
    mesh_instance.material_override = mat
    mesh_instance.position = pos
    add_child(mesh_instance)
    return mesh_instance

func _build_goal() -> void:
    var white := Color("#F4F4F4")
    _add_box("القائم الأيسر", Vector3(-GOAL_WIDTH / 2, GOAL_HEIGHT / 2, -24.0), Vector3(0.16, GOAL_HEIGHT, 0.16), white)
    _add_box("القائم الأيمن", Vector3(GOAL_WIDTH / 2, GOAL_HEIGHT / 2, -24.0), Vector3(0.16, GOAL_HEIGHT, 0.16), white)
    _add_box("عارضة المرمى", Vector3(0, GOAL_HEIGHT, -24.0), Vector3(GOAL_WIDTH, 0.16, 0.16), white)
    # Back net represented by subtle dark translucent panels.
    _add_box("شبكة خلفية", Vector3(0, 1.2, -25.1), Vector3(GOAL_WIDTH, 2.4, 0.035), Color(0.78, 0.86, 0.92, 0.25))
    _add_box("شبكة جانبية يسار", Vector3(-3.66, 1.2, -24.55), Vector3(0.035, 2.4, 1.1), Color(0.78, 0.86, 0.92, 0.20))
    _add_box("شبكة جانبية يمين", Vector3(3.66, 1.2, -24.55), Vector3(0.035, 2.4, 1.1), Color(0.78, 0.86, 0.92, 0.20))

func _build_stands() -> void:
    var stand_mat := Color("#17243A")
    _add_box("مدرج خلفي", Vector3(0, 3.0, -29.0), Vector3(44, 6, 2), stand_mat)
    _add_box("مدرج يسار", Vector3(-21.0, 2.5, -5), Vector3(2, 5, 52), stand_mat)
    _add_box("مدرج يمين", Vector3(21.0, 2.5, -5), Vector3(2, 5, 52), stand_mat)
    for i in range(12):
        var light := OmniLight3D.new()
        light.position = Vector3(-18 + i * 3.25, 8.0, -27.5)
        light.light_color = Color("#DCE9FF")
        light.light_energy = 1.5
        light.omni_range = 14.0
        add_child(light)

func _build_keeper() -> void:
    keeper = Node3D.new()
    keeper.name = "حارس المرمى"
    keeper.position = Vector3(0, 0, -22.8)
    add_child(keeper)
    var body := _make_capsule(Color("#F2C230"), 0.42, 1.2)
    body.position = Vector3(0, 1.0, 0)
    keeper.add_child(body)
    var head := _make_sphere(Color("#D9A27F"), 0.25)
    head.position = Vector3(0, 1.78, 0)
    keeper.add_child(head)
    var left_arm := _make_box_mesh(Color("#F2C230"), Vector3(0.75, 0.16, 0.18))
    left_arm.position = Vector3(-0.53, 1.22, 0)
    keeper.add_child(left_arm)
    var right_arm := _make_box_mesh(Color("#F2C230"), Vector3(0.75, 0.16, 0.18))
    right_arm.position = Vector3(0.53, 1.22, 0)
    keeper.add_child(right_arm)

func _build_ball() -> void:
    ball = RigidBody3D.new()
    ball.name = "كرة القدم"
    ball.mass = 0.43
    ball.physics_material_override = PhysicsMaterial.new()
    ball.physics_material_override.bounce = 0.42
    ball.physics_material_override.friction = 0.55
    var sphere := SphereMesh.new()
    sphere.radius = 0.22
    sphere.height = 0.44
    var visual := MeshInstance3D.new()
    visual.mesh = sphere
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color.WHITE
    mat.roughness = 0.45
    visual.material_override = mat
    ball.add_child(visual)
    var shape := CollisionShape3D.new()
    var sphere_shape := SphereShape3D.new()
    sphere_shape.radius = 0.22
    shape.shape = sphere_shape
    ball.add_child(shape)
    add_child(ball)

func _make_capsule(color: Color, radius: float, height: float) -> MeshInstance3D:
    var m := MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = radius
    mesh.height = height
    m.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    m.material_override = mat
    return m

func _make_sphere(color: Color, radius: float) -> MeshInstance3D:
    var m := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    m.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    m.material_override = mat
    return m

func _make_box_mesh(color: Color, size: Vector3) -> MeshInstance3D:
    var m := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    m.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    m.material_override = mat
    return m

func _build_camera() -> void:
    var camera := Camera3D.new()
    camera.position = Vector3(0, 5.4, 1.5)
    camera.rotation_degrees = Vector3(-9, 0, 0)
    camera.fov = 62
    add_child(camera)
    camera.current = true

func _build_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(root)

    var top := PanelContainer.new()
    top.position = Vector2(35, 25)
    top.size = Vector2(650, 132)
    top.add_theme_stylebox_override("panel", _panel_style(Color(0.025, 0.04, 0.075, 0.88), Color("#8B5CF6")))
    root.add_child(top)
    var top_v := VBoxContainer.new()
    top_v.add_theme_constant_override("separation", 7)
    top.add_child(top_v)

    team_label = _label("العراق 🇮🇶", 30, Color("#F4F2FF"), true)
    top_v.add_child(team_label)
    score_label = _label("الأهداف: 0     المحاولات: 0", 25, Color("#E7DDFE"))
    top_v.add_child(score_label)
    status_label = _label("استعد للتسديد!", 24, Color("#B9F6CA"))
    top_v.add_child(status_label)

    var bottom := PanelContainer.new()
    bottom.anchor_left = 0.08
    bottom.anchor_right = 0.92
    bottom.anchor_top = 0.86
    bottom.anchor_bottom = 0.98
    bottom.add_theme_stylebox_override("panel", _panel_style(Color(0.025, 0.04, 0.075, 0.86), Color("#554080")))
    root.add_child(bottom)
    hint_label = _label("وجّه التسديدة بالأسهم أو العصا اليسرى  |  زر A / ✕ للتسديد  |  B / ○ لإعادة الكرة", 21, Color.WHITE)
    hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    bottom.add_child(hint_label)

    var team_hint := _label("تبديل الفريق: زر LB / L1 أو Tab", 18, Color("#D5C8F5"))
    team_hint.position = Vector2(35, 175)
    root.add_child(team_hint)

func _label(value: String, font_size: int, color: Color, bold := false) -> Label:
    var l := Label.new()
    l.text = value
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_color", color)
    l.add_theme_color_override("font_shadow_color", Color.BLACK)
    l.add_theme_constant_override("shadow_offset_x", 2)
    l.add_theme_constant_override("shadow_offset_y", 2)
    l.add_theme_font_size_override("font_size", font_size)
    l.text_direction = Control.TEXT_DIRECTION_RTL
    if arabic_font:
        l.add_theme_font_override("font", arabic_font)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    if bold:
        l.add_theme_color_override("font_outline_color", Color("#30204D"))
        l.add_theme_constant_override("outline_size", 2)
    return l

func _panel_style(bg: Color, border_color: Color) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = bg
    s.border_color = border_color
    s.set_border_width_all(2)
    s.set_corner_radius_all(18)
    s.content_margin_left = 22
    s.content_margin_right = 22
    s.content_margin_top = 12
    s.content_margin_bottom = 12
    return s

func _update_team() -> void:
    if team_label:
        team_label.text = "الفريق: " + TEAM_NAMES[selected_team]
        var colors: Array = TEAM_COLORS[selected_team]
        team_label.add_theme_color_override("font_color", colors[0])
    if status_label:
        status_label.text = "تم اختيار " + TEAM_NAMES[selected_team] + " — بالتوفيق!"

func _reset_ball() -> void:
    if not ball:
        return
    ball.freeze = true
    ball.global_position = Vector3(0, 0.24, -11.0)
    ball.linear_velocity = Vector3.ZERO
    ball.angular_velocity = Vector3.ZERO
    ball.freeze = false
    shot_taken = false
    idle_ball_timer = 0.0
    aim_x = 0.0
    aim_y = 0.0
    if keeper:
        keeper.position.x = 0.0
    if status_label:
        status_label.text = "وجّه الكرة ثم اضغط زر التسديد"
    _update_score()

func _shoot() -> void:
    if not ball or shot_taken:
        return
    shot_taken = true
    attempts += 1
    var direction := Vector3(aim_x * 0.58, 0.12 + aim_y * 0.55, -1.0).normalized()
    var power := 18.5
    ball.apply_central_impulse(direction * power)
    ball.apply_torque_impulse(Vector3(rng.randf_range(-1.2, 1.2), 0, rng.randf_range(-1.2, 1.2)))
    shot_cooldown = 0.7
    if status_label:
        status_label.text = "تسديدة قوية! ⚽"
    _check_goal_later()

func _check_goal_later() -> void:
    await get_tree().create_timer(0.85).timeout
    if not is_instance_valid(ball):
        return
    var p := ball.global_position
    if p.z <= -24.0 and abs(p.x) < GOAL_WIDTH / 2.0 - 0.15 and p.y < GOAL_HEIGHT - 0.15 and p.y > 0.15:
        goals += 1
        status_label.text = "گوووول! هدف رائع! 🥅"
    elif shot_taken:
        status_label.text = "محاولة جميلة! جرّب مرة ثانية"
    _update_score()

func _update_score() -> void:
    if score_label:
        score_label.text = "الأهداف: %d     المحاولات: %d" % [goals, attempts]
